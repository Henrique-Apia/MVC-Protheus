import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PoMenuItem, PoMenuModule } from '@po-ui/ng-components';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, PoMenuModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  // "icon" + "shortLabel" em todo item de 1º nível é o que habilita o po-menu
  // a ser recolhido/expandido (ver documentação do po-menu). Como hoje só
  // existe a rota de chamados, fica um item só - mas já pronto pra crescer.
  protected readonly menus: PoMenuItem[] = [
    { label: 'Usuario', shortLabel: 'Usuario', icon: 'an an-user-circle', link: '/' },
    { label: 'Chamados', shortLabel: 'Chamados', icon: 'an an-headset', link: '/' },
    { label: 'Agenda', shortLabel: 'Agenda', icon: 'an an-calendar', link: '/' },
    { label: 'Ordem de Serviço', shortLabel: 'OS', icon: 'an an-clipboard-text', link: '/' }
  ];
}
