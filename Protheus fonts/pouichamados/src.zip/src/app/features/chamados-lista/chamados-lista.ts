import { ChangeDetectionStrategy, Component, OnInit, ViewChild, computed, inject, signal } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import {
  PoButtonModule,
  PoFieldModule,
  PoModalComponent,
  PoModalModule,
  PoNotificationService
} from '@po-ui/ng-components';
import {
  PoPageDynamicTableActions,
  PoPageDynamicTableCustomAction,
  PoPageDynamicTableFilters,
  PoPageDynamicTableModule
} from '@po-ui/ng-templates';
import { ProAppConfigService } from '@totvs/protheus-lib-core';

import {
  AgendarResposta,
  AlterarResposta,
  Chamado,
  IncluirResposta,
  VerAgendaItem
} from '../../core/models/chamado.model';
import { ChamadoService } from '../../core/services/chamado.service';
import { ComponenteItem, TipoLupa } from '../../core/models/componente.model';
import { AnotacaoEditorComponent } from '../../shared/anotacao-editor';
import { LupaModalComponent } from '../../shared/lupa-modal';

// Mesma legenda de status do CNSA001 (AddLegend), usada no modal de detalhe
// e no combo (desabilitado) da tela de Incluir/Editar.
const STATUS_LABEL: Record<string, string> = {
  '1': 'Aberto',
  '2': 'Pendente Apia',
  '3': 'Pendente Cliente',
  '4': 'Fechado'
};

// Opções do combo "Tipo" - valores confirmados por Henrique (print da tela).
const TIPO_OPTIONS: ReadonlyArray<{ value: string; label: string }> = [
  { value: 'I', label: 'I - INSTALACAO' },
  { value: 'M', label: 'M - MANUTENCAO' },
  { value: 'S', label: 'S - SUPORTE' },
  { value: 'T', label: 'T - TREINAMENTO' },
  { value: 'A', label: 'A - ATUALIZACAO' },
  { value: 'D', label: 'D - DUVIDA' }
];

type ModoFormulario = 'incluir' | 'editar';

@Component({
  selector: 'app-chamados-lista',
  imports: [
    PoPageDynamicTableModule,
    PoModalModule,
    PoButtonModule,
    PoFieldModule,
    FormsModule,
    LupaModalComponent,
    AnotacaoEditorComponent
  ],
  templateUrl: './chamados-lista.html',
  styleUrl: './chamados-lista.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChamadosListaComponent implements OnInit {
  private readonly proAppConfigService = inject(ProAppConfigService);
  private readonly poNotificationService = inject(PoNotificationService);
  private readonly chamadoService = inject(ChamadoService);

  protected readonly tipoOptions = TIPO_OPTIONS;

  @ViewChild('modalDetalhe', { static: true }) protected modalDetalhe!: PoModalComponent;
  @ViewChild('modalExcluir', { static: true }) protected modalExcluir!: PoModalComponent;
  @ViewChild('modalAssumir', { static: true }) protected modalAssumir!: PoModalComponent;
  @ViewChild('modalAgendar', { static: true }) protected modalAgendar!: PoModalComponent;
  @ViewChild('modalFormulario', { static: true }) protected modalFormulario!: PoModalComponent;
  @ViewChild('modalVerAgenda', { static: true }) protected modalVerAgenda!: PoModalComponent;
  @ViewChild('modalAnotacoes', { static: true }) protected modalAnotacoes!: PoModalComponent;
  @ViewChild('lupaModal', { static: true }) protected lupaModal!: LupaModalComponent;

  protected readonly exibirBotaoFechar = signal(false);
  protected readonly chamadoDetalhe = signal<Chamado | null>(null);

  // Estado do modal de exclusão - agora pede o Id Chamado tambem (nao vem
  // mais de uma linha clicada, ja que Excluir virou botao de pagina, sempre
  // visivel, por pedido explicito - "nao quero que so apareca quando tiver
  // chamado, sempre tem que aparecer").
  protected idChExcluir = '';
  protected motivoExclusao = '';
  protected readonly carregandoExclusao = signal(false);

  // Estado do modal de assumir - mesmo motivo do excluir: agora e botao de
  // pagina, sempre visivel, entao precisa perguntar o Id Chamado.
  protected idChAssumir = '';
  protected readonly carregandoAssumir = signal(false);

  // --- Formulário de Incluir/Editar (UNIFICADO) ---------------------------
  // Pedido: "A função Editar deve ficar exatamente igual ao Incluir (Novo),
  // utilizando a mesma assinatura de métodos e estrutura." - por isso um
  // ÚNICO conjunto de campos/modal serve pros dois modos; só muda o método
  // do ChamadoService chamado em confirmarFormulario() (incluir vs alterar).
  //
  // Campos e obrigatoriedade (*) confirmados na tela real "Registro de
  // Chamados - INCLUIR" do CNSA001 (print de Henrique): Assunto, Dt Abertura,
  // Status (fixo, não editável aqui), Tipo, Projeto e Tarefa são obrigatórios;
  // Cliente/Loja/Consultor/Email do Cliente são opcionais.
  protected readonly modoFormulario = signal<ModoFormulario>('incluir');
  protected idChFormulario = '';
  protected assuntoFormulario = '';
  protected dtAberturaFormulario = '';
  protected statusFormulario = '1';
  protected tipoFormulario = '';
  protected codClienteFormulario = '';
  protected lojaClienteFormulario = '';
  protected nomeClienteFormulario = '';
  protected codConsultorFormulario = '';
  protected nomeTecnicoFormulario = '';
  protected emailClienteFormulario = '';
  protected projetoFormulario = '';
  protected nomeProjetoFormulario = '';
  protected tarefaFormulario = '';
  protected nomeTarefaFormulario = '';
  protected readonly carregandoFormulario = signal(false);

  // Guarda qual campo dispara a lupa compartilhada (LupaModalComponent é uma
  // instância única reaproveitada pelos 4 campos de consulta).
  private origemLupa: TipoLupa | null = null;

  // --- Ver Agenda -----------------------------------------------------------
  protected idChVerAgenda = '';
  protected readonly agendaItens = signal<VerAgendaItem[]>([]);
  protected readonly carregandoVerAgenda = signal(false);

  // --- Anotações (rich text, campo memo único) -------------------------------
  protected idChAnotacao = '';
  protected anotacaoConteudo = '';
  protected readonly carregandoAnotacao = signal(false);
  protected readonly salvandoAnotacao = signal(false);

  // Estado do modal de agendamento - botão de página (selectable: true),
  // mesmo padrão do Excluir/Assumir: seleciona a linha, clica no botão,
  // preenche o resto. Campos confirmados pela tela real "Model Agendas -
  // Nova Agenda" do CNSA001 (print enviado por Henrique). Sequência é
  // gerada automaticamente no ADVPL (não é campo aqui). Agendador, se
  // deixado em branco, o ADVPL assume o técnico da sessão logada - por
  // isso não é exposto no formulário. "Anexo" e o segundo campo "Data" da
  // tela não foram implementados (fora de escopo, já sinalizado no .prw).
  //
  // dataFimAgendar é extensão nossa (não existe na tela original): se
  // deixado em branco, assume o mesmo valor de dataInicioAgendar (um dia
  // só); se preenchido com uma data posterior, cria um agendamento por dia
  // no intervalo (limite de 60 dias, validado no servidor).
  protected idChAgendar = '';
  protected dataInicioAgendar = '';
  protected dataFimAgendar = '';
  protected codTecnicoAgendar = '';
  protected horaInicioAgendar = '';
  protected horaFimAgendar = '';
  protected codClienteAgendar = '';
  protected lojaClienteAgendar = '01';
  protected descricaoAgendar = '';
  protected confirmacaoAgendar = '';
  protected turnoAgendar = '';
  protected agInternaAgendar = '';
  protected agCobravelAgendar = '';
  protected tipoAgendaAgendar = '';
  protected projetoAgendar = '';
  protected revisaoAgendar = '';
  protected tarefaAgendar = '';
  protected tipoHoraAgendar = '';
  protected readonly carregandoAgendar = signal(false);

  /**
   * Endpoint usado pelo po-page-dynamic-table (busca, busca avançada e
   * paginação via "Carregar mais resultados"). O ChamadosRestAdapterInterceptor
   * (core/interceptors) traduz page/pageSize/hasNext pro contrato do ADVPL.
   */
  protected readonly servicoApi = '/rest/CNSACHAMADOS';

  /**
   * Campos usados tanto pra montar as colunas da tabela quanto pra busca
   * avançada (padrão po-page-dynamic-table). "status" usa type:'label'
   * (tag colorida por linha) — não existe suporte a type:'subtitle' com o
   * botão automático de legenda dentro deste template, então essa
   * funcionalidade foi conscientemente removida ao adotar o padrão TOTVS.
   * "meus" e "semResponsavel" ficam com visible:false pra não virar coluna,
   * aparecendo só como filtro (switch) na busca avançada.
   */
  protected readonly campos: Array<PoPageDynamicTableFilters> = [
    { property: 'idCh', label: 'Id Chamado', key: true, filter: true, gridColumns: 3 },
    { property: 'data', label: 'Dt Abertura', type: 'date', format: 'dd/mm/yyyy', filter: true, gridColumns: 3 },
    { property: 'assunto', label: 'Assunto', filter: true, gridColumns: 6 },
    { property: 'cliente', label: 'Cliente', filter: true, gridColumns: 6 },
    {
      property: 'tecnico',
      label: 'Técnico',
      filter: true,
      gridColumns: 6,
      visible: false,
      allowColumnsManager: true
    },
    {
      property: 'status',
      label: 'Status',
      type: 'label',
      filter: true,
      optionsMulti: true,
      options: [
        { label: 'Aberto', value: '1' },
        { label: 'Pendente Apia', value: '2' },
        { label: 'Pendente Cliente', value: '3' },
        { label: 'Fechado', value: '4' }
      ],
      labels: [
        { value: '1', label: 'Aberto', color: 'color-10' },
        { value: '2', label: 'Pendente Apia', color: 'color-09' },
        { value: '3', label: 'Pendente Cliente', color: 'color-08' },
        { value: '4', label: 'Fechado', color: 'color-07' }
      ]
    },
    {
      property: 'meus',
      label: 'Somente meus chamados',
      type: 'boolean',
      filter: true,
      visible: false,
      booleanTrue: 'Sim',
      booleanFalse: 'Não'
    },
    {
      property: 'semResponsavel',
      label: 'Sem responsável',
      type: 'boolean',
      filter: true,
      visible: false,
      booleanTrue: 'Sim',
      booleanFalse: 'Não'
    }
  ];

  // "Visualizar" segue como ação nativa de detalhe (ícone de olho na linha).
  // "Editar" (lápis) agora abre o MESMO formulário do Incluir, em modo edição.
  protected readonly acoes: PoPageDynamicTableActions = {
    detail: (_id: string, resource: Chamado) => this.abrirDetalhe(resource),
    edit: (_id: string, resource: Chamado) => {
      this.abrirEditar(resource);
      return {};
    }
  };

  // Ações de página (botões no topo, sempre visíveis, independente de a
  // tabela ter dado ou não). Excluir/Assumir/Agendar/Ver Agenda/Anotações
  // usam `selectable: true` - o po-page-dynamic-table mostra os checkboxes
  // de linha automaticamente e passa os itens marcados pra função
  // (getSelectedItemsKeys por baixo dos panos). "Novo" não é selecionável -
  // sempre visível, abre o formulário em branco.
  protected readonly acoesPagina = computed<Array<PoPageDynamicTableCustomAction>>(() => {
    const acoes: Array<PoPageDynamicTableCustomAction> = [
      { label: 'Novo', icon: 'an an-plus-circle', action: this.abrirIncluir.bind(this) },
      { label: 'Excluir', icon: 'an an-trash', selectable: true, action: this.excluirSelecionado.bind(this) },
      { label: 'Assumir', icon: 'an an-user-circle-plus', selectable: true, action: this.assumirSelecionado.bind(this) },
      { label: 'Agendar', icon: 'an an-calendar-plus', selectable: true, action: this.agendarSelecionado.bind(this) },
      { label: 'Ver Agenda', icon: 'an an-calendar-check', selectable: true, action: this.verAgendaSelecionado.bind(this) },
      { label: 'Anotações', icon: 'an an-note-pencil', selectable: true, action: this.anotacoesSelecionado.bind(this) },
      { label: 'Imprimir Browse', icon: 'an an-printer', action: this.imprimirBrowse.bind(this) }
    ];

    if (this.exibirBotaoFechar()) {
      acoes.push({ label: 'Sair', icon: 'an an-sign-out', action: this.fechar.bind(this) });
    }

    return acoes;
  });

  ngOnInit(): void {
    this.exibirBotaoFechar.set(this.proAppConfigService.insideProtheus());
  }

  protected statusLabel(status: string): string {
    return STATUS_LABEL[status] ?? status;
  }

  protected fechar(): void {
    this.proAppConfigService.callAppClose(false);
  }

  private abrirDetalhe(resource: Chamado): void {
    this.chamadoDetalhe.set(resource);
    this.modalDetalhe.open();
  }

  // --- Incluir / Editar (formulário unificado) ----------------------------

  /** Botão de página "Novo" - abre o formulário em branco, modo Incluir. */
  protected abrirIncluir(): void {
    this.modoFormulario.set('incluir');
    this.idChFormulario = '';
    this.assuntoFormulario = '';
    this.dtAberturaFormulario = new Date().toISOString().slice(0, 10);
    this.statusFormulario = '1';
    this.tipoFormulario = '';
    this.codClienteFormulario = '';
    this.lojaClienteFormulario = '';
    this.nomeClienteFormulario = '';
    this.codConsultorFormulario = '';
    this.nomeTecnicoFormulario = '';
    this.emailClienteFormulario = '';
    this.projetoFormulario = '';
    this.nomeProjetoFormulario = '';
    this.tarefaFormulario = '';
    this.nomeTarefaFormulario = '';
    this.modalFormulario.open();
  }

  /**
   * Ação nativa "edit" (lápis) - abre o MESMO formulário, modo Editar.
   * LIMITAÇÃO CONHECIDA (mesma já documentada no Alterar antigo, agora
   * estendida): o GET de listagem só devolve idCh/assunto/status/data e os
   * NOMES de cliente/técnico - nunca os códigos, nem tipo/projeto/tarefa/
   * email. Esses campos abrem em branco na edição; se o usuário não
   * preencher, o servidor simplesmente não altera (alteração parcial).
   */
  private abrirEditar(resource: Chamado): void {
    this.modoFormulario.set('editar');
    this.idChFormulario = resource.idCh;
    this.assuntoFormulario = resource.assunto;
    this.dtAberturaFormulario = resource.data;
    this.statusFormulario = resource.status;
    this.tipoFormulario = '';
    this.codClienteFormulario = '';
    this.lojaClienteFormulario = '';
    this.nomeClienteFormulario = resource.cliente;
    this.codConsultorFormulario = '';
    this.nomeTecnicoFormulario = resource.tecnico;
    this.emailClienteFormulario = '';
    this.projetoFormulario = '';
    this.nomeProjetoFormulario = '';
    this.tarefaFormulario = '';
    this.nomeTarefaFormulario = '';
    this.modalFormulario.open();
  }

  /**
   * Abre a lupa compartilhada pro campo indicado. "tarefa" exige projeto já
   * selecionado (lupa em cascata, confirmado por Henrique).
   */
  protected abrirLupa(tipo: TipoLupa): void {
    if (tipo === 'tarefa' && !this.projetoFormulario.trim()) {
      this.poNotificationService.warning('Selecione um projeto antes de escolher a tarefa.');
      return;
    }
    this.origemLupa = tipo;
    this.lupaModal.abrir(tipo, tipo === 'tarefa' ? this.projetoFormulario.trim() : '');
  }

  /** Callback único da lupa compartilhada - despacha pro campo de origem. */
  protected aoSelecionarLupa(item: ComponenteItem): void {
    switch (this.origemLupa) {
      case 'cliente':
        this.codClienteFormulario = item.codigo;
        this.lojaClienteFormulario = item.complemento || '01';
        this.nomeClienteFormulario = item.descricao;
        break;
      case 'tecnico':
        this.codConsultorFormulario = item.codigo;
        this.nomeTecnicoFormulario = item.descricao;
        break;
      case 'projeto':
        if (this.projetoFormulario !== item.codigo) {
          // Projeto mudou - a tarefa antiga não necessariamente pertence ao
          // novo projeto (cascata), então limpa a seleção anterior.
          this.tarefaFormulario = '';
          this.nomeTarefaFormulario = '';
        }
        this.projetoFormulario = item.codigo;
        this.nomeProjetoFormulario = item.descricao;
        break;
      case 'tarefa':
        this.tarefaFormulario = item.codigo;
        this.nomeTarefaFormulario = item.descricao;
        break;
    }
  }

  /**
   * Confirma o formulário - chama incluir() ou alterar() dependendo do modo.
   * Validação client-side espelha os obrigatórios (*) da tela real: Assunto,
   * Dt Abertura, Tipo, Projeto e Tarefa.
   */
  protected confirmarFormulario(): void {
    const assunto = this.assuntoFormulario.trim();
    const dtAbertura = this.dtAberturaFormulario.trim();
    const tipo = this.tipoFormulario.trim();
    const projeto = this.projetoFormulario.trim();
    const tarefa = this.tarefaFormulario.trim();
    const emailCliente = this.emailClienteFormulario.trim();

    if (!assunto) {
      this.poNotificationService.warning('Informe o assunto do chamado.');
      return;
    }
    if (!dtAbertura) {
      this.poNotificationService.warning('Informe a data de abertura.');
      return;
    }
    if (!tipo) {
      this.poNotificationService.warning('Informe o tipo do chamado.');
      return;
    }
    if (!projeto) {
      this.poNotificationService.warning('Informe o projeto.');
      return;
    }
    if (!tarefa) {
      this.poNotificationService.warning('Informe a tarefa.');
      return;
    }
    // Validação de formato somada à do <po-email> nativo (máscara/erro
    // inline) - dupla checagem antes de disparar a requisição.
    if (emailCliente && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailCliente)) {
      this.poNotificationService.warning('Informe um e-mail válido para o cliente.');
      return;
    }

    this.carregandoFormulario.set(true);

    const camposComuns = {
      assunto,
      dtAbertura,
      tipo,
      projeto,
      tarefa,
      codCliente: this.codClienteFormulario.trim() || undefined,
      lojaCliente: this.lojaClienteFormulario.trim() || undefined,
      emailCliente: emailCliente || undefined,
      codConsultor: this.codConsultorFormulario.trim() || undefined
    };

    if (this.modoFormulario() === 'incluir') {
      this.chamadoService.incluir(camposComuns).subscribe({
        next: (resposta: IncluirResposta) => {
          this.poNotificationService.success(`Chamado #${resposta.idCh} incluído com sucesso.`);
          this.carregandoFormulario.set(false);
          this.modalFormulario.close();
        },
        error: (err: HttpErrorResponse) => {
          const mensagem = err.error?.erro ?? 'Não foi possível incluir o chamado. Verifique a conexão com o servidor REST.';
          this.poNotificationService.error(mensagem);
          this.carregandoFormulario.set(false);
        }
      });
    } else {
      this.chamadoService.alterar({ idCh: this.idChFormulario, ...camposComuns }).subscribe({
        next: (resposta: AlterarResposta) => {
          this.poNotificationService.success(`Chamado #${resposta.idCh} alterado com sucesso.`);
          this.carregandoFormulario.set(false);
          this.modalFormulario.close();
        },
        error: (err: HttpErrorResponse) => {
          const mensagem = err.error?.erro ?? 'Não foi possível alterar o chamado. Verifique a conexão com o servidor REST.';
          this.poNotificationService.error(mensagem);
          this.carregandoFormulario.set(false);
        }
      });
    }
  }

  /**
   * Chamada quando o botão "Excluir" (selectable) é clicado. Recebe as
   * chaves dos itens marcados na tabela (array de {idCh} - sempre array,
   * mesmo com 1 selecionado, porque o mecanismo nativo é multi-seleção).
   */
  private excluirSelecionado(selecionados: Array<{ idCh: string }> | undefined): void {
    if (!selecionados || selecionados.length === 0) {
      this.poNotificationService.warning('Selecione um chamado na tabela.');
      return;
    }
    if (selecionados.length > 1) {
      this.poNotificationService.warning('Selecione apenas um chamado por vez.');
      return;
    }

    this.idChExcluir = selecionados[0].idCh;
    this.motivoExclusao = '';
    this.modalExcluir.open();
  }

  /**
   * Confirma a exclusão de verdade. Cascata completa: remove o chamado,
   * remove agenda vinculada, envia e-mail de cancelamento se havia técnico
   * designado (tudo do lado do ADVPL).
   * LIMITAÇÃO CONHECIDA: a tabela não recarrega sozinha depois do sucesso
   * (loadDataFromAPI é private no template).
   */
  protected confirmarExclusao(): void {
    const idCh = this.idChExcluir.trim();
    if (!idCh) {
      this.poNotificationService.warning('Informe o número do chamado.');
      return;
    }

    this.carregandoExclusao.set(true);

    this.chamadoService.excluir(idCh, this.motivoExclusao.trim()).subscribe({
      next: (resposta) => {
        this.poNotificationService.success(`Chamado #${resposta.idCh} excluído com sucesso.`);
        this.carregandoExclusao.set(false);
        this.modalExcluir.close();
      },
      error: (err: HttpErrorResponse) => {
        const mensagem = err.error?.erro ?? 'Não foi possível excluir o chamado. Verifique a conexão com o servidor REST.';
        this.poNotificationService.error(mensagem);
        this.carregandoExclusao.set(false);
      }
    });
  }

  /**
   * Chamada quando o botão "Assumir" (selectable) é clicado. Mesma lógica
   * do Excluir - recebe as chaves dos itens marcados na tabela.
   */
  private assumirSelecionado(selecionados: Array<{ idCh: string }> | undefined): void {
    if (!selecionados || selecionados.length === 0) {
      this.poNotificationService.warning('Selecione um chamado na tabela.');
      return;
    }
    if (selecionados.length > 1) {
      this.poNotificationService.warning('Selecione apenas um chamado por vez.');
      return;
    }

    this.idChAssumir = selecionados[0].idCh;
    this.modalAssumir.open();
  }

  /**
   * Aciona o POST de "Assumir" de verdade (endpoint validado via curl).
   * LIMITAÇÃO CONHECIDA: mesma do Excluir - a tabela não recarrega sozinha
   * depois do sucesso.
   */
  protected confirmarAssumir(): void {
    const idCh = this.idChAssumir.trim();
    if (!idCh) {
      this.poNotificationService.warning('Informe o número do chamado.');
      return;
    }

    this.carregandoAssumir.set(true);

    this.chamadoService.assumir(idCh).subscribe({
      next: (resposta) => {
        this.poNotificationService.success(
          `Chamado #${resposta.idCh} assumido com sucesso por ${resposta.tecnico}.`
        );
        this.carregandoAssumir.set(false);
        this.modalAssumir.close();
      },
      error: (err: HttpErrorResponse) => {
        const mensagem = err.error?.erro ?? 'Não foi possível assumir o chamado. Verifique a conexão com o servidor REST.';
        this.poNotificationService.error(mensagem);
        this.carregandoAssumir.set(false);
      }
    });
  }

  /**
   * Chamada quando o botão "Agendar" (selectable) é clicado. Mesma lógica
   * do Excluir/Assumir - recebe as chaves dos itens marcados na tabela.
   */
  private agendarSelecionado(selecionados: Array<{ idCh: string }> | undefined): void {
    if (!selecionados || selecionados.length === 0) {
      this.poNotificationService.warning('Selecione um chamado na tabela.');
      return;
    }
    if (selecionados.length > 1) {
      this.poNotificationService.warning('Selecione apenas um chamado por vez.');
      return;
    }

    this.idChAgendar = selecionados[0].idCh;
    this.dataInicioAgendar = '';
    this.dataFimAgendar = '';
    this.codTecnicoAgendar = '';
    this.horaInicioAgendar = '';
    this.horaFimAgendar = '';
    this.codClienteAgendar = '';
    this.lojaClienteAgendar = '01';
    this.descricaoAgendar = '';
    this.confirmacaoAgendar = '';
    this.turnoAgendar = '';
    this.agInternaAgendar = '';
    this.agCobravelAgendar = '';
    this.tipoAgendaAgendar = '';
    this.projetoAgendar = '';
    this.revisaoAgendar = '';
    this.tarefaAgendar = '';
    this.tipoHoraAgendar = '';
    this.modalAgendar.open();
  }

  /**
   * Confirma o agendamento de verdade. Campos obrigatórios seguem a mesma
   * validação do CNSA_AGENDAR (data, técnico, horário início/fim, cliente).
   * Se dataFimAgendar ficar em branco, assume o mesmo valor de
   * dataInicioAgendar (agendamento de um dia só).
   * LIMITAÇÃO CONHECIDA: mesma dos outros - a tabela não recarrega sozinha
   * depois do sucesso.
   */
  protected confirmarAgendar(): void {
    const idCh = this.idChAgendar.trim();
    const dataInicio = this.dataInicioAgendar.trim();
    const dataFim = this.dataFimAgendar.trim() || dataInicio;
    const codTecnico = this.codTecnicoAgendar.trim();
    const horaInicio = this.horaInicioAgendar.trim();
    const horaFim = this.horaFimAgendar.trim();
    const codCliente = this.codClienteAgendar.trim();

    if (!idCh) {
      this.poNotificationService.warning('Chamado inválido.');
      return;
    }
    if (!dataInicio) {
      this.poNotificationService.warning('Informe a data do agendamento.');
      return;
    }
    if (!codTecnico) {
      this.poNotificationService.warning('Informe o técnico.');
      return;
    }
    if (!horaInicio || !horaFim) {
      this.poNotificationService.warning('Informe o horário de início e término.');
      return;
    }
    if (!codCliente) {
      this.poNotificationService.warning('Informe o cliente.');
      return;
    }

    this.carregandoAgendar.set(true);

    this.chamadoService
      .agendar({
        idCh,
        dataInicio,
        dataFim,
        codTecnico,
        horaInicio,
        horaFim,
        codCliente,
        lojaCliente: this.lojaClienteAgendar.trim(),
        descricao: this.descricaoAgendar.trim(),
        confirmacao: this.confirmacaoAgendar.trim(),
        turno: this.turnoAgendar.trim(),
        agInterna: this.agInternaAgendar.trim(),
        agCobravel: this.agCobravelAgendar.trim(),
        tipoAgenda: this.tipoAgendaAgendar.trim(),
        projeto: this.projetoAgendar.trim(),
        revisao: this.revisaoAgendar.trim(),
        tarefa: this.tarefaAgendar.trim(),
        tipoHora: this.tipoHoraAgendar.trim()
      })
      .subscribe({
        next: (resposta: AgendarResposta) => {
          this.poNotificationService.success(resposta.mensagem);
          this.carregandoAgendar.set(false);
          this.modalAgendar.close();
        },
        error: (err: HttpErrorResponse) => {
          const mensagem = err.error?.erro ?? 'Não foi possível criar o agendamento. Verifique a conexão com o servidor REST.';
          this.poNotificationService.error(mensagem);
          this.carregandoAgendar.set(false);
        }
      });
  }

  /**
   * Chamada quando o botão "Ver Agenda" (selectable) é clicado - lista os
   * agendamentos (SZ6) já criados pro chamado selecionado.
   */
  private verAgendaSelecionado(selecionados: Array<{ idCh: string }> | undefined): void {
    if (!selecionados || selecionados.length === 0) {
      this.poNotificationService.warning('Selecione um chamado na tabela.');
      return;
    }
    if (selecionados.length > 1) {
      this.poNotificationService.warning('Selecione apenas um chamado por vez.');
      return;
    }

    this.idChVerAgenda = selecionados[0].idCh;
    this.agendaItens.set([]);
    this.modalVerAgenda.open();
    this.carregandoVerAgenda.set(true);

    this.chamadoService.verAgenda(this.idChVerAgenda).subscribe({
      next: (resposta) => {
        this.agendaItens.set(resposta.items ?? []);
        this.carregandoVerAgenda.set(false);
      },
      error: (err: HttpErrorResponse) => {
        const mensagem = err.error?.erro ?? 'Não foi possível carregar a agenda do chamado.';
        this.poNotificationService.error(mensagem);
        this.carregandoVerAgenda.set(false);
      }
    });
  }

  /**
   * Chamada quando o botão "Anotações" (selectable) é clicado - carrega a
   * anotação atual (campo memo) no po-rich-text.
   */
  private anotacoesSelecionado(selecionados: Array<{ idCh: string }> | undefined): void {
    if (!selecionados || selecionados.length === 0) {
      this.poNotificationService.warning('Selecione um chamado na tabela.');
      return;
    }
    if (selecionados.length > 1) {
      this.poNotificationService.warning('Selecione apenas um chamado por vez.');
      return;
    }

    this.idChAnotacao = selecionados[0].idCh;
    this.anotacaoConteudo = '';
    this.modalAnotacoes.open();
    this.carregandoAnotacao.set(true);

    this.chamadoService.buscarAnotacao(this.idChAnotacao).subscribe({
      next: (resposta) => {
        this.anotacaoConteudo = resposta.anotacao ?? '';
        this.carregandoAnotacao.set(false);
      },
      error: (err: HttpErrorResponse) => {
        const mensagem = err.error?.erro ?? 'Não foi possível carregar a anotação do chamado.';
        this.poNotificationService.error(mensagem);
        this.carregandoAnotacao.set(false);
      }
    });
  }

  /** Salva a anotação - sobrescreve a anterior (campo memo único, sem histórico). */
  protected salvarAnotacao(): void {
    this.salvandoAnotacao.set(true);

    this.chamadoService.salvarAnotacao(this.idChAnotacao, this.anotacaoConteudo).subscribe({
      next: () => {
        this.poNotificationService.success('Anotação salva com sucesso.');
        this.salvandoAnotacao.set(false);
        this.modalAnotacoes.close();
      },
      error: (err: HttpErrorResponse) => {
        const mensagem = err.error?.erro ?? 'Não foi possível salvar a anotação.';
        this.poNotificationService.error(mensagem);
        this.salvandoAnotacao.set(false);
      }
    });
  }

  // "Imprimir Browse" mantém o window.print() de antes.
  private imprimirBrowse(): void {
    window.print();
  }
}
