import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ComponenteResposta, TipoLupa } from '../models/componente.model';

const COMPONENTES_URL = '/rest/CNSACOMPONENTES';

/**
 * Consultas de apoio ("lupas") usadas nos campos Cliente/Consultor/Projeto/
 * Tarefa da tela de Incluir/Editar chamado - espelha o WSRESTFUL
 * CNSACOMPONENTES (ComponentesRest.prw).
 */
@Injectable({ providedIn: 'root' })
export class ComponenteService {
  private readonly http = inject(HttpClient);

  /**
   * @param tipo tecnico | cliente | projeto | tarefa
   * @param filtro texto livre (código ou nome/descrição) - vazio traz os 20 primeiros
   * @param projeto OBRIGATÓRIO quando tipo === 'tarefa' (lupa em cascata) - ignorado nos demais tipos
   */
  buscar(tipo: TipoLupa, filtro: string, projeto?: string): Observable<ComponenteResposta> {
    let url = `${COMPONENTES_URL}?tipo=${encodeURIComponent(tipo)}&filtro=${encodeURIComponent(filtro ?? '')}`;
    if (tipo === 'tarefa' && projeto) {
      url += `&projeto=${encodeURIComponent(projeto)}`;
    }
    return this.http.get<ComponenteResposta>(url);
  }
}
